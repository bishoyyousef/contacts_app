import 'package:contacts/core/colors_manager/app_colors.dart';
import 'package:contacts/core/routes_manager/routes_manager.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ContactsApp extends StatelessWidget {
  const ContactsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: Size(402,874),
      child: MaterialApp(
        color: AppColors.darkBlue,
        debugShowCheckedModeBanner: false,
        initialRoute: RoutesManager.homeScreen,
        routes: RoutesManager().routes,

      ),
    );
  }
}
