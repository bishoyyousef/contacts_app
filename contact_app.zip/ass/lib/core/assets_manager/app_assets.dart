class AppAssets{
  static const String routeLogo = "assets/images/route_logo.png";
  static const String headerLogo = "assets/images/header_logo.png";
  static const String homeScreenBackground = "assets/images/home_screen_background.png";
  static const String galleryImage = "assets/images/gallery_image.png";
  static const String messi = "assets/images/messi.png";
}