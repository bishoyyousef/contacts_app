import 'package:contacts/presentation/home_screen/home.dart';
import 'package:flutter/material.dart';

class RoutesManager {
  static const String homeScreen = "/home";

  Map<String, Widget Function(BuildContext)> routes = {
    homeScreen: (_) => Home(),
  };
}
