import 'package:contacts/contacts_app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const ContactsApp());
}
