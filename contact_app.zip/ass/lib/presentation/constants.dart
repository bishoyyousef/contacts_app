class User {
  String name;
  String email;
  String phone;
  String imagePath;

  User({
    required this.name,
    required this.email,
    required this.phone,
    required this.imagePath,
  });
}
