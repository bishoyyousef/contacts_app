import 'dart:io';

import 'package:contacts/core/assets_manager/app_assets.dart';
import 'package:contacts/core/colors_manager/app_colors.dart';
import 'package:contacts/presentation/constants.dart';
import 'package:contacts/presentation/home_screen/widgets/user_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<UserCard> users = [];
  var _userName = '';
  var _userEmail = '';
  var _userPhone = '';
  var _userImage = '';
  int _currentIndex = 0;
  File? image;

  Future pickImage() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (image == null) return;

    final imageTemporary = File(image.path);
    setState(() {
      this.image = imageTemporary;
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.darkBlue,
          title: Image.asset(AppAssets.headerLogo, width: 80.h, height: 240.h),
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Column(
            children: [
              users.isEmpty
                  ? Center(child: Image.asset(AppAssets.homeScreenBackground))
                  : Text(""),
              users.isEmpty
                  ? Text(
                    "There is No Contacts Added Here",
                    style: GoogleFonts.inter(
                      color: AppColors.gold,
                      fontSize: 20,
                      fontWeight: FontWeight.w400,
                    ),
                  )
                  : SizedBox(
                    height: 650.h,
                    child: Expanded(
                      child: GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 3 / 4,
                        ),
                        scrollDirection: Axis.vertical,
                        itemCount: users.length,
                        itemBuilder: (context, index) {
                          _currentIndex = index;
                          return users[_currentIndex];
                        },
                      ),
                    ),
                  ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Tooltip(
                    message: "Add Contact",
                    child: FloatingActionButton(
                      onPressed: () {
                        showModalBottomSheet(
                          enableDrag: true,
                          context: context,
                          backgroundColor: AppColors.darkBlue,
                          shape: RoundedRectangleBorder(),
                          builder: (context) {
                            return Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      InkWell(
                                        splashColor: AppColors.darkBlue,
                                        onTap: () {
                                          pickImage();
                                        },
                                        child:
                                            image != null
                                                ? Image.file(
                                                  image!,
                                                  height: 150.h,
                                                  width: 110.w,
                                                  fit: BoxFit.fill,
                                                )
                                                : Image.asset(
                                                  AppAssets.galleryImage,
                                                ),
                                      ),
                                      SizedBox(width: 8),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "user Name",
                                            style: TextStyle(
                                              color: AppColors.gold,
                                              fontWeight: FontWeight.w300,
                                              fontSize: 20.sp,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 200,
                                            child: Divider(
                                              color: AppColors.white,
                                            ),
                                          ),
                                          Text(
                                            overflow: TextOverflow.ellipsis,
                                            "userEmail@gmail.com",
                                            style: TextStyle(
                                              color: AppColors.gold,
                                              fontWeight: FontWeight.w300,
                                              fontSize: 20.sp,
                                            ),
                                          ),
                                          SizedBox(
                                            width: 200,
                                            child: Divider(
                                              color: AppColors.white,
                                            ),
                                          ),
                                          Text(
                                            "+200000000000000",
                                            style: TextStyle(
                                              color: AppColors.gold,
                                              fontWeight: FontWeight.w300,
                                              fontSize: 20.sp,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10.sp),
                                  buildCustomTextField(
                                    text: "Enter User Name",
                                    onChange: (value) {
                                      setState(() {
                                        _userName = value;
                                      });
                                    },
                                  ),
                                  buildCustomTextField(
                                    text: "Enter User Email",
                                    onChange: (value) {
                                      setState(() {
                                        _userEmail = value;
                                      });
                                    },
                                  ),
                                  buildCustomTextField(
                                    text: "Enter User Phone",
                                    onChange: (value) {
                                      setState(() {
                                        _userPhone = value;
                                      });
                                    },
                                  ),
                                  Container(
                                    width: double.infinity,
                                    height: 50,
                                    margin: EdgeInsets.symmetric(horizontal: 2),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        if (image != null &&
                                            _userName.isNotEmpty &&
                                            _userEmail.isNotEmpty &&
                                            _userPhone.isNotEmpty) {
                                          setState(() {
                                            users.add(
                                              UserCard(
                                                user: User(
                                                  name:
                                                      _userName.isNotEmpty
                                                          ? _userName
                                                          : 'Unnamed',
                                                  email:
                                                      _userEmail.isNotEmpty
                                                          ? _userEmail
                                                          : 'No email',
                                                  phone:
                                                      _userPhone.isNotEmpty
                                                          ? _userPhone
                                                          : 'No phone',
                                                  imagePath:
                                                      image?.path ??
                                                      AppAssets.messi,
                                                ),
                                                onDelete: () {},
                                              ),
                                            );
                                          });
                                          Navigator.pop(context);
                                        }
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: AppColors.gold,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        "ADD User",
                                        style: TextStyle(
                                          color: AppColors.darkBlue,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                      backgroundColor: AppColors.gold,
                      child: Icon(Icons.add, color: AppColors.darkBlue),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        backgroundColor: AppColors.darkBlue,
      ),
    );
  }

  Widget buildCustomTextField({
    required String text,
    required void Function(String) onChange,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        onChanged: onChange,
        style: TextStyle(
          fontSize: 16.sp,
          color: AppColors.lightBlue,
          fontWeight: FontWeight.w400,
        ),
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: AppColors.gold),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: AppColors.gold),
          ),
          labelText: text,
          labelStyle: TextStyle(fontSize: 16.sp, color: AppColors.lightBlue),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: AppColors.gold),
          ),
        ),
      ),
    );
  }
}
