import 'dart:io';

import 'package:contacts/core/assets_manager/app_assets.dart';
import 'package:contacts/core/colors_manager/app_colors.dart';
import 'package:contacts/presentation/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class UserCard extends StatelessWidget {
  UserCard({super.key, required this.user,required this.onDelete});

  final User user;
  final Function onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.gold,

      child: Column(
        children: [
          Stack(
            children: [
              Image.file(
                File(user.imagePath),
                fit: BoxFit.fill,
                height: 170.h,
                width: 170.w,
              ),
              Positioned(
                top: 105,
                left: 6,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 1),
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.gold,
                    borderRadius: BorderRadius.circular(2),
                  ),
                  child: Text(user.name, overflow: TextOverflow.ellipsis),
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            spacing: 8,
            children: [
              Icon(Icons.email_rounded),
              Expanded(
                child: Text(user.email, overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
          Row(
            spacing: 8,
            children: [
              Icon(Icons.phone),
              Expanded(
                child: Text(user.phone, overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
          Spacer(),
          ElevatedButton(
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.all(Colors.red),
            ),
            onPressed: onDelete(),
            child: Row(
              children: [
                Icon(Icons.delete, color: Colors.white),
                Text("Delete", style: TextStyle(color: Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
